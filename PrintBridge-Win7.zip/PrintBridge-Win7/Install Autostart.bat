@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Print Bridge - start with Windows
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  echo Asking for administrator rights...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" >nul 2>&1
  exit /b
)

echo.
echo   Print Bridge - start automatically with Windows
echo   ---------------------------------------------------------------
echo.

rem --- find pythonw.exe, which runs without a console window -----------
set "PYW="
for /f "usebackq delims=" %%P in (`py -3 -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))" 2^>nul`) do set "PYW=%%P"
if not exist "!PYW!" (
  for /f "usebackq delims=" %%P in (`python -c "import sys,os;print(os.path.join(os.path.dirname(sys.executable),'pythonw.exe'))" 2^>nul`) do set "PYW=%%P"
)
if not exist "!PYW!" if exist "%ProgramFiles%\Python38\pythonw.exe" set "PYW=%ProgramFiles%\Python38\pythonw.exe"
if not exist "!PYW!" if exist "%ProgramFiles(x86)%\Python38-32\pythonw.exe" set "PYW=%ProgramFiles(x86)%\Python38-32\pythonw.exe"
if not exist "!PYW!" if exist "%LOCALAPPDATA%\Programs\Python\Python38\pythonw.exe" set "PYW=%LOCALAPPDATA%\Programs\Python\Python38\pythonw.exe"
if not exist "!PYW!" (
  echo   Could not find Python. Run "Start Print Bridge.bat" once first -
  echo   it will tell you which version Windows 7 needs - then come back here.
  goto :done
)
echo   Python:   !PYW!

rem --- firewall, in case the bridge has never been started by hand -----
netsh advfirewall firewall delete rule name="Print Bridge (IPP printing)" >nul 2>&1
netsh advfirewall firewall delete rule name="Print Bridge (Bonjour discovery)" >nul 2>&1
netsh advfirewall firewall add rule name="Print Bridge (IPP printing)" dir=in action=allow protocol=TCP localport=631 profile=private,domain >nul 2>&1
netsh advfirewall firewall add rule name="Print Bridge (Bonjour discovery)" dir=in action=allow protocol=UDP localport=5353 profile=private,domain >nul 2>&1
echo   Firewall: ports open

rem --- the scheduled task ---------------------------------------------
schtasks /Delete /TN "Print Bridge" /F >nul 2>&1
schtasks /Create /TN "Print Bridge" /SC ONLOGON /RL HIGHEST /F ^
  /TR "\"!PYW!\" \"%~dp0run_hidden.pyw\"" >nul 2>&1
if errorlevel 1 (
  echo   ! Could not create the scheduled task.
  goto :done
)
echo   Task:     created - it will start at every logon, with no window
echo.
echo   Starting it now...
schtasks /Run /TN "Print Bridge" >nul 2>&1
timeout /t 4 >nul

rem --- tell the user where it is (ipconfig: no Get-NetIPAddress here) ---
set "IP="
for /f "tokens=2 delims=:" %%I in ('ipconfig ^| findstr /i /c:"IPv4"') do (
  if not defined IP set "IP=%%I"
)
if defined IP set "IP=!IP: =!"

echo.
echo   Print Bridge is running in the background.
if defined IP echo       Web page:  http://!IP!:631
echo       Log file:  %~dp0printbridge.log
echo.
echo   Your phone should list the printer straight from Share ^-^> Print.
echo   To undo this, run "Stop Starting With Windows.bat".

:done
echo.
pause
endlocal
